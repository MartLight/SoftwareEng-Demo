// Shows how far a write has got. The four screens of every blockchain action:
// waiting, in progress, success, failure. This component draws the "in progress" one.
export type Step = 0 | 1 | 2 | 3;

const LABELS = ["1 Confirm in wallet", "2 Sent to the network", "3 Added to a block", "4 Receipt"];

export default function OperationSteps({ step, detail }: { step: Step; detail?: string }) {
  return (
    <div className="stack" style={{ marginTop: 0 }}>
      <div className="steps">
        {LABELS.map((label, i) => (
          <span key={label} className={`step ${i < step ? "done" : i === step ? "on" : ""}`}>
            {label}
          </span>
        ))}
      </div>
      {detail && <div className="muted">tx <code>{detail.slice(0, 18)}...</code></div>}
    </div>
  );
}
