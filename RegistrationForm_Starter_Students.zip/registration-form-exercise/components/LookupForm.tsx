import { useState } from "react";
import { RegistryApi, VehicleInfo } from "../utils/registry";
import { friendlyError } from "../utils/errors";

export default function LookupForm({ api }: { api: RegistryApi | null }) {
  const [pseudonym, setPseudonym] = useState("");
  const [info, setInfo] = useState<VehicleInfo | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function lookup() {
    const name = pseudonym.trim();
    if (!name) return;
    setError("");
    setInfo(null);
    if (!api) return setError("Connect the wallet first, or switch to demo mode.");
    setLoading(true);
    try {
      setInfo(await api.lookup(name));
    } catch (err) {
      setError(friendlyError(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card stack">
      <h2>Look up a vehicle (a read)</h2>
      <div className="row">
        <input className="input" placeholder="pseudonym" value={pseudonym} onChange={(e) => setPseudonym(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && lookup()} />
        <button className="btn" onClick={lookup} disabled={loading}>{loading ? "Reading..." : "Look up"}</button>
      </div>
      {error && <div className="msg err">{error}</div>}
      {info && !info.isRegistered && <div className="msg warn">Nothing is registered under "{pseudonym.trim()}".</div>}
      {info?.isRegistered && (
        <table className="tbl">
          <tbody>
            <tr><td>Owner</td><td><code>{info.owner}</code></td></tr>
            <tr><td>Registered</td><td>{info.registeredAt}</td></tr>
          </tbody>
        </table>
      )}
    </div>
  );
}
