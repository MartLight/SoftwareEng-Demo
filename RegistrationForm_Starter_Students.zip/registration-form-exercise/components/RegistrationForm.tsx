import { FormEvent, useEffect, useRef, useState } from "react";
import OperationSteps, { Step } from "./OperationSteps";
import ReceiptCard from "./ReceiptCard";
import { RegistryApi } from "../utils/registry";
import { Receipt } from "../utils/receipts";
import { friendlyError } from "../utils/errors";
import { MAX_LENGTH, normalizePseudonym, validatePseudonym } from "../utils/validation";

// ---------------------------------------------------------------------------------------------
// THE EXERCISE LIVES IN THIS FILE (steps 2 to 6 of WORKSHEET.md). Everything it needs is imported
// above and is already written: the registry API, the progress steps, the receipt card, the error
// messages, and your validation functions from Step 1.
// ---------------------------------------------------------------------------------------------

// The four screens of a write: exactly one is true at any time. (Given.)
type Op =
  | { state: "idle" }
  | { state: "pending"; step: Step; tx?: string }
  | { state: "success"; receipt: Receipt }
  | { state: "error"; message: string };

interface RegistrationFormProps {
  api: RegistryApi | null;
  onRegistered: (r: Receipt) => void;   // ↑ call this after a success, so the rest of the page refreshes
}

export default function RegistrationForm({ api, onRegistered }: RegistrationFormProps) {
  // TODO 2: STATE. What must the form remember?  (the text typed so far, ...)
  //   Step 3 adds "has the user left the field yet?".  Step 5 uses `op` (declare it here: useState<Op>({ state: "idle" })).

  // TODO 3: DERIVED VALUES. Work these out from state on every render; do not store them in state:
  //   error, showError, pending, canSubmit.

  // TODO 5: EVENT HANDLER. handleSubmit(e: FormEvent): validate, then api.register(...), then update `op`.
  //   api.register(name, onProgress) is already written; see utils/registry.ts for how it is called.

  // TODO 6: SIDE EFFECT. After a success, put the cursor back in the field (useEffect + useRef).

  // TODO 4: RENDER. Replace the placeholder below with the real form:
  //   <form> with a label, an input, a character counter, an error line, a Register button, and the
  //   four-state output (OperationSteps while pending, an error message, a success message + ReceiptCard).
  return (
    <div className="card stack">
      <h2>Register a vehicle</h2>
      <div className="msg warn">TODO: build the form here. Follow steps 2 to 6 in WORKSHEET.md.</div>
    </div>
  );
}
