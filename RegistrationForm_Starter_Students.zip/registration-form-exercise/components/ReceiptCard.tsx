import { Receipt } from "../utils/receipts";

export default function ReceiptCard({ receipt }: { receipt: Receipt }) {
  return (
    <div className="receipt">
      <div className="head">
        <span>{receipt.action}{receipt.simulated ? " (simulated)" : ""}</span>
        <span>{receipt.subject}</span>
      </div>
      <div className="line"><span>owner</span><code>{receipt.owner}</code></div>
      <div className="line"><span>block</span><span>#{receipt.blockNumber}</span></div>
      <div className="line"><span>time</span><span>{receipt.time}</span></div>
      <div className="line"><span>tx</span><code>{receipt.txHash}</code></div>
    </div>
  );
}
