import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ModeSwitch, { Mode } from "./ModeSwitch";
import WalletBar from "./WalletBar";
import RegistrationForm from "./RegistrationForm";
import LookupForm from "./LookupForm";
import ReceiptCard from "./ReceiptCard";
import { Wallet } from "../utils/chain";
import { chainApi, demoApi } from "../utils/registry";
import { Receipt } from "../utils/receipts";

// The MODULE: one screen made of components, with the integration logic kept in one place.
// It decides where data comes from (demo or chain) and hands the result down as props.
export default function VehicleModule() {
  const [mode, setMode] = useState<Mode>("demo");
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [rejectNext, setRejectNext] = useState(false);
  const [mine, setMine] = useState<string | null>(null);
  const [history, setHistory] = useState<Receipt[]>([]);

  // A ref lets the simulation read the checkbox's CURRENT value when the "wallet" asks.
  const rejectRef = useRef(false);
  rejectRef.current = rejectNext;

  // Start in blockchain mode only if a wallet exists in this browser.
  useEffect(() => {
    if (window.ethereum?.selectedAddress) setMode("chain");
  }, []);

  const api = useMemo(() => {
    if (mode === "demo") return demoApi({ rejectNext: () => (rejectRef.current ? (setRejectNext(false), true) : false) });
    return wallet ? chainApi(wallet) : null;
  }, [mode, wallet]);

  // Reading "which identity is mine" is a chain read; run it whenever the source changes.
  const refreshMine = useCallback(async () => {
    setMine(null);
    if (!api) return;
    try {
      setMine(await api.myIdentity());
    } catch {
      setMine(null);
    }
  }, [api]);
  useEffect(() => { void refreshMine(); }, [refreshMine]);

  function handleRegistered(r: Receipt) {
    setHistory((old) => [r, ...old]);
    void refreshMine();
  }

  return (
    <div className="stack">
      <ModeSwitch mode={mode} onChange={setMode} rejectNext={rejectNext} onRejectChange={setRejectNext} />
      {mode === "chain" && (
        <WalletBar wallet={wallet} onConnected={setWallet} onDisconnected={() => setWallet(null)} />
      )}

      <div className="grid2">
        <div className="stack">
          <RegistrationForm api={api} onRegistered={handleRegistered} />
          <LookupForm api={api} />
        </div>
        <div className="stack">
          <div className="card">
            <h2>Your identity (read from {mode === "demo" ? "the simulation" : "the chain"})</h2>
            {mine ? <span className="badge ok">{mine}</span> : <span className="muted">none registered yet</span>}
          </div>
          <div className="card">
            <h2>This session</h2>
            {history.length === 0 && <div className="muted">Registrations you make appear here.</div>}
            <div className="stack">
              {history.map((r) => <ReceiptCard key={r.txHash} receipt={r} />)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
