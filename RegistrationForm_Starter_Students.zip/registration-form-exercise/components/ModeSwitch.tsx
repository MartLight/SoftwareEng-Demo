export type Mode = "demo" | "chain";

interface ModeSwitchProps {
  mode: Mode;
  onChange: (m: Mode) => void;
  rejectNext: boolean;
  onRejectChange: (v: boolean) => void;
}

export default function ModeSwitch({ mode, onChange, rejectNext, onRejectChange }: ModeSwitchProps) {
  return (
    <div className="card">
      <div className="row between">
        <div>
          <b>Data source</b>
          <div className="muted">
            {mode === "demo"
              ? "Simulated chain in the browser. Works with no wallet and no Ganache."
              : "The real contracts, through your wallet."}
          </div>
        </div>
        <div className="tabs">
          <button className={mode === "demo" ? "on" : ""} onClick={() => onChange("demo")}>Demo</button>
          <button className={mode === "chain" ? "on" : ""} onClick={() => onChange("chain")}>Blockchain</button>
        </div>
      </div>
      {mode === "demo" && (
        <label className="row" style={{ marginTop: 10, cursor: "pointer" }}>
          <input type="checkbox" checked={rejectNext} onChange={(e) => onRejectChange(e.target.checked)} />
          Simulate "reject in wallet" on the next registration (to see the failure screen)
        </label>
      )}
    </div>
  );
}
