import { useEffect, useState } from "react";
import { CHAIN_NAMES, Wallet, connectWallet } from "../utils/chain";

interface WalletBarProps {
  wallet: Wallet | null;                 // ↓ the page owns the wallet and passes it down
  onConnected: (w: Wallet) => void;      // ↑ the bar reports a connection
  onDisconnected: () => void;
}

export default function WalletBar({ wallet, onConnected, onDisconnected }: WalletBarProps) {
  const [error, setError] = useState("");
  const [hasWallet, setHasWallet] = useState<boolean | null>(null);

  useEffect(() => setHasWallet(!!window.ethereum), []);

  async function connect() {
    setError("");
    try {
      onConnected(await connectWallet());
    } catch (err: any) {
      setError(err.message);
    }
  }

  // Keep the screen in step with MetaMask: switching network or account in the wallet must update the page.
  useEffect(() => {
    if (!window.ethereum?.on) return;
    const changed = () => window.location.reload(); // simplest safe way to re-read everything for the new chain
    const accounts = (a: string[]) => (a.length === 0 ? onDisconnected() : changed());
    window.ethereum.on("chainChanged", changed);
    window.ethereum.on("accountsChanged", accounts);
    return () => {
      window.ethereum?.removeListener?.("chainChanged", changed);
      window.ethereum?.removeListener?.("accountsChanged", accounts);
    };
  }, [onDisconnected]);

  return (
    <div className="card">
      <div className="row between">
        <div>
          <b>Wallet</b>
          <div className="muted">
            {hasWallet === false ? "No wallet detected in this browser." : "MetaMask or any browser wallet."}
          </div>
        </div>
        {wallet ? (
          <div className="row">
            <span className="pill">{CHAIN_NAMES[wallet.chainId] ?? "chain"} ({wallet.chainId})</span>
            <span className="pill">{wallet.account.slice(0, 6)}...{wallet.account.slice(-4)}</span>
          </div>
        ) : (
          <button className="btn" onClick={connect}>Connect Wallet</button>
        )}
      </div>
      {error && <div className="msg err" style={{ marginTop: 10 }}>{error}</div>}
    </div>
  );
}
