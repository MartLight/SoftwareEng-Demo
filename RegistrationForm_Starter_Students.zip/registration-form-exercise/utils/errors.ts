// Turns the raw error from a wallet or a contract into a sentence a user can act on.
// The raw message is for developers; this is for the person looking at the screen.
export function friendlyError(err: any): string {
  const raw = [err?.message, err?.cause?.message, err?.data?.message, err?.error?.message]
    .filter(Boolean)
    .join(" | ");

  if (err?.code === 4001 || /user (denied|rejected)|rejected the request|ACTION_REJECTED/i.test(raw)) {
    return "You rejected the transaction in your wallet. Nothing was written to the chain.";
  }
  if (/EnforcedPause|paused/i.test(raw)) return "Registrations are paused by the administrator right now.";
  if (/already registered/i.test(raw)) return "That pseudonym is already registered. Choose another one.";
  if (/revoked and cannot register/i.test(raw)) return "This wallet's identity is revoked, so it cannot register a new one.";
  if (/cannot be empty/i.test(raw)) return "A pseudonym cannot be empty.";
  if (/insufficient funds/i.test(raw)) return "This wallet does not have enough ETH to pay for the transaction.";
  if (/No wallet found/i.test(raw)) return String(err.message);
  if (/not deployed on chain/i.test(raw)) return String(err.message);
  return raw.slice(0, 220) || "Something went wrong.";
}
