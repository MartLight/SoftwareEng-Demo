import { Wallet, contractsFor } from "./chain";
import { Receipt, formatTime } from "./receipts";

// The component talks to this small interface and does not care what is behind it.
// Behind it is either the real chain or a simulation, so the same screen works in both.
export type Progress = "wallet" | "submitted" | "mined";

export interface VehicleInfo {
  isRegistered: boolean;
  owner: string;
  registeredAt: string;
}

export interface RegistryApi {
  mode: "demo" | "chain";
  register(pseudonym: string, onProgress: (p: Progress, detail?: string) => void): Promise<Receipt>;
  lookup(pseudonym: string): Promise<VehicleInfo>;
  myIdentity(): Promise<string | null>;
}

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------- the real chain
export function chainApi(wallet: Wallet): RegistryApi {
  return {
    mode: "chain",

    async register(pseudonym, onProgress) {
      const { registry } = contractsFor(wallet);
      const method = registry.methods.registerVehicle(pseudonym);

      // Estimating first makes a contract rule (for example "already registered") fail
      // BEFORE the wallet pop-up, with the contract's own reason.
      const estimate = await method.estimateGas({ from: wallet.account });
      onProgress("wallet");

      const pending: any = method.send({ from: wallet.account, gas: String((estimate * 12n) / 10n) });
      pending.on("transactionHash", (hash: string) => onProgress("submitted", hash));
      const receipt: any = await pending;
      onProgress("mined");

      const event = receipt.events?.VehicleRegistered?.returnValues;
      return {
        action: "Vehicle Registered",
        subject: pseudonym,
        owner: event?.owner ?? wallet.account,
        txHash: receipt.transactionHash,
        blockNumber: Number(receipt.blockNumber),
        time: event ? formatTime(event.timestamp) : new Date().toLocaleString(),
      };
    },

    async lookup(pseudonym) {
      const { registry } = contractsFor(wallet);
      const v: any = await registry.methods.getVehicle(pseudonym).call();
      return {
        isRegistered: v.isRegistered,
        owner: v.owner,
        registeredAt: v.isRegistered ? formatTime(v.registrationTime) : "",
      };
    },

    async myIdentity() {
      const { registry } = contractsFor(wallet);
      const name: string = await registry.methods.ownerToPseudonym(wallet.account).call();
      return name || null;
    },
  };
}

// ------------------------------------------------------------ the simulation
const DEMO_ACCOUNT = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266";
const store = new Map<string, { owner: string; time: number }>([
  ["KA-2041-GH", { owner: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8", time: Date.now() - 86400000 * 20 }],
  ["GR-7710-AB", { owner: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC", time: Date.now() - 86400000 * 9 }],
]);
let myName: string | null = null;
let block = 1200;

export function demoApi(opts: { rejectNext: () => boolean }): RegistryApi {
  return {
    mode: "demo",

    async register(pseudonym, onProgress) {
      await wait(250);
      if (store.has(pseudonym)) throw new Error("Returned error: revert Pseudonym already registered");
      onProgress("wallet");
      await wait(1100);
      if (opts.rejectNext()) throw Object.assign(new Error("User denied transaction signature"), { code: 4001 });
      const hash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
      onProgress("submitted", hash);
      await wait(900);
      store.set(pseudonym, { owner: DEMO_ACCOUNT, time: Date.now() });
      myName = pseudonym;
      onProgress("mined");
      return {
        action: "Vehicle Registered",
        subject: pseudonym,
        owner: DEMO_ACCOUNT,
        txHash: hash,
        blockNumber: ++block,
        time: new Date().toLocaleString(),
        simulated: true,
      };
    },

    async lookup(pseudonym) {
      await wait(300);
      const v = store.get(pseudonym);
      return { isRegistered: !!v, owner: v?.owner ?? "", registeredAt: v ? new Date(v.time).toLocaleString() : "" };
    },

    async myIdentity() {
      await wait(150);
      return myName;
    },
  };
}
