// Rules for a vehicle pseudonym. Pure functions: no React, no blockchain, so they are easy to test.
//
// YOUR JOB (Step 1): make these two functions follow the rules in WORKSHEET.md, until `npm test` is all green.
//
// Why validate in the page when the contract already checks? The contract only refuses an EMPTY name, and every
// refusal there costs gas and time. The page can catch the obvious mistakes instantly, for free, and in words
// the user understands. (The contract stays the final judge: never rely on the page alone.)

export const MIN_LENGTH = 3;
export const MAX_LENGTH = 32;

// TODO 1a: "  ka-2041-gh " must become "KA-2041-GH".
// Why? Pseudonyms are case-sensitive on the chain, so "ka-1" and "KA-1" would be two different vehicles.
export function normalizePseudonym(raw: string): string {
  return raw; // <- replace this line
}

// TODO 1b: return the message to show the user, or null when the value is acceptable.
// Check the rules in the order given in the worksheet; the FIRST one that fails wins.
export function validatePseudonym(raw: string): string | null {
  return null; // <- replace this with your checks
}
