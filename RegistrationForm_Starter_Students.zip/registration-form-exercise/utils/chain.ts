import Web3 from "web3";
import abi from "./abi.json";
import deployments from "./deployments.json";
import chains from "@/shared/chains.json";
import { Addresses, envAddresses } from "./config";

declare global {
  interface Window {
    ethereum?: any;
  }
}

export interface Wallet {
  web3: Web3;
  account: string;
  chainId: string;
}

// Names come from shared/chains.json, the same list the main project uses (plus the local Ganache chains).
export const CHAIN_NAMES: Record<string, string> = {
  "1337": "Ganache",
  "5777": "Ganache",
  ...Object.fromEntries(chains.chains.map((c) => [String(c.chainId), c.name])),
};

// STEP 1: connect the wallet (MetaMask) and learn which chain it is on.
export async function connectWallet(): Promise<Wallet> {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error("No wallet found. Install MetaMask, or use the demo data button.");
  }
  await window.ethereum.request({ method: "eth_requestAccounts" });
  const web3 = new Web3(window.ethereum);
  const accounts = await web3.eth.getAccounts();
  const chainId = (await web3.eth.getChainId()).toString();
  return { web3, account: accounts[0], chainId };
}

// deployments.json has the main project's shape: { "<chainId>": { VehicleRegistry: { address }, ... } }.
type Deployment = Partial<Record<"VehicleRegistry" | "RevocationManager" | "LicenseRegistry", { address?: string }>>;
const DEPLOYED = deployments as Record<string, Deployment>;

// STEP 2: find the contract addresses for THIS chain. Environment file first, then deployments.json
// (written by `npm run deploy:local` here, or copied from the main project with `npm run sync`).
export function resolveAddresses(chainId: string) {
  const fromEnv = envAddresses(chainId);
  const fromFile = DEPLOYED[chainId] ?? {};
  const pick = (key: keyof Addresses, name: keyof Deployment) => {
    const file = fromFile[name]?.address;
    return {
      value: fromEnv[key] ?? file,
      source: fromEnv[key] ? "environment file" : file ? "deployments.json" : "not found",
    };
  };
  return {
    registry: pick("registry", "VehicleRegistry"),
    revocation: pick("revocation", "RevocationManager"),
    license: pick("license", "LicenseRegistry"),
  };
}

// STEP 3: build a contract object for each deployed contract.
export function contractsFor(wallet: Wallet) {
  const found = resolveAddresses(wallet.chainId);
  const need = (name: string, v: { value?: string }) => {
    if (!v.value) {
      throw new Error(
        `${name} is not deployed on chain ${wallet.chainId}. Run "npm run deploy:local" (Ganache must be running: "npm run chain"), ` +
          `or "npm run sync -- <path to the main project>", or set the addresses in the environment file.`
      );
    }
    return v.value;
  };
  const { web3 } = wallet;
  return {
    registry: new web3.eth.Contract(abi.VehicleRegistry as any, need("VehicleRegistry", found.registry)),
    revocation: new web3.eth.Contract(abi.RevocationManager as any, need("RevocationManager", found.revocation)),
    license: new web3.eth.Contract(abi.LicenseRegistry as any, need("LicenseRegistry", found.license)),
  };
}
