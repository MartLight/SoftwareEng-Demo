// A receipt is built from the transaction's own result (hash, block, emitted event). Nothing is stored anywhere.
export interface Receipt {
  action: string;
  subject: string;
  owner: string;
  txHash: string;
  blockNumber: number;
  time: string;
  simulated?: boolean;
}

export function formatTime(seconds: bigint | number | string): string {
  return new Date(Number(seconds) * 1000).toLocaleString();
}
