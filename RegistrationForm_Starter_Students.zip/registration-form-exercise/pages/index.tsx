import VehicleModule from "../components/VehicleModule";

export default function Page() {
  return (
    <div className="container stack">
      <div className="hero">
        <h1>Demo 6: A front-end module with a smart contract</h1>
        <div className="muted">
          Pages and components from demos 1 to 4, wallet and reads from demo 5, plus writes with progress, success and failure.
        </div>
      </div>
      <VehicleModule />
    </div>
  );
}
