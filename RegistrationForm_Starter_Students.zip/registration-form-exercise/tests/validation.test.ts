import test from "node:test";
import assert from "node:assert/strict";
import { MAX_LENGTH, normalizePseudonym, validatePseudonym } from "../utils/validation";

// These tests are the SPECIFICATION of the rules (see the table in the worksheet).
// Run them with:  npm test

test("normalize: trims spaces and upper-cases", () => {
  assert.equal(normalizePseudonym("  ka-2041-gh "), "KA-2041-GH");
  assert.equal(normalizePseudonym("KA-2041-GH"), "KA-2041-GH");
});

test("empty or only spaces: asks for a pseudonym", () => {
  assert.equal(validatePseudonym(""), "Enter a pseudonym.");
  assert.equal(validatePseudonym("    "), "Enter a pseudonym.");
});

test("too short", () => {
  assert.equal(validatePseudonym("ab"), "Use at least 3 characters.");
  assert.equal(validatePseudonym(" a "), "Use at least 3 characters.");
});

test("too long", () => {
  assert.equal(validatePseudonym("A".repeat(MAX_LENGTH + 1)), "Use at most 32 characters.");
});

test("characters: letters, digits and hyphens only", () => {
  assert.equal(validatePseudonym("KA 2041"), "Use letters, digits and hyphens only.");
  assert.equal(validatePseudonym("KA_2041"), "Use letters, digits and hyphens only.");
  assert.equal(validatePseudonym("KA.2041!"), "Use letters, digits and hyphens only.");
});

test("hyphens may not start or end the name", () => {
  assert.equal(validatePseudonym("-KA-2041"), "A pseudonym cannot start or end with a hyphen.");
  assert.equal(validatePseudonym("KA-2041-"), "A pseudonym cannot start or end with a hyphen.");
});

test("valid names return null", () => {
  assert.equal(validatePseudonym("KA-2041-GH"), null);
  assert.equal(validatePseudonym("  KA-2041-GH  "), null); // outer spaces are tolerated
  assert.equal(validatePseudonym("abc"), null);             // lower case is fine: it is normalized later
  assert.equal(validatePseudonym("A".repeat(MAX_LENGTH)), null);
});

test("the first failing rule wins", () => {
  assert.equal(validatePseudonym("a b"), "Use letters, digits and hyphens only."); // long enough, bad character
  assert.equal(validatePseudonym("a!"), "Use at least 3 characters.");              // too short comes first
});
