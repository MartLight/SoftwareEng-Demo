# Exercise: build the vehicle registration form

**Time:** about 2 hours. **Work:** alone, on your own Git branch. **Hand in:** your branch, two screenshots and a short reflection (section 8).

You are given a working app (demo 6). Its screen has a registration area, but the **form is missing**. You will build
it by hand: the rules, the input, the error messages, the button and the submit logic. When you finish, a user can
register a vehicle and see the receipt, and a mistake such as `KA 12` is caught before anything is sent.

## 1. The requirement

> **User story.** As a driver, I want a registration form that tells me at once if my pseudonym is not acceptable,
> so that I do not waste time or fees on a registration that will be refused.

**Acceptance criteria** (this is also your self-check in section 5):

| # | Given / When / Then |
|---|---|
| AC1 | **Given** the form is empty, **then** the Register button is disabled and no error is showing yet. |
| AC2 | **When** the user types a bad value and leaves the field, **then** a red message says what is wrong, and the button stays disabled. |
| AC3 | **When** the value is valid, **then** the message disappears and the button is enabled. |
| AC4 | A counter shows how many characters are typed out of 32. |
| AC5 | **When** the user presses Enter or clicks Register with a valid value, **then** the progress steps appear, the input is locked, and a receipt is shown. |
| AC6 | The name sent is saved in capitals (`ka-7001-xy` becomes `KA-7001-XY`). |
| AC7 | **After a success**, the field is empty, has no error, and the cursor is back in it. |
| AC8 | **After a failure** (duplicate name, or the wallet rejecting), the message is shown and **what the user typed is kept**. |

## 2. Design

```
Register a vehicle
Pseudonym                                   12/32
[ KA 12                                       ]     <- red border when invalid and touched
 Use letters, digits and hyphens only.              <- error line (grey hint when there is no error)
[ Register ]                                        <- disabled until the value is valid
```

The form is always in one of **four states**: idle, pending, success, error. Only one is true at a time. The `Op` type
in the starter already says so. State is what the component remembers; everything else (is it valid? can we submit?
should we show the error?) is **worked out from state** each time the component renders.

## 3. Set up

```bash
git checkout -b feature/registration-form      # all your work goes on this branch
npm install                                    # once (about 2 minutes)
npm test                                       # 1 test passes, 7 fail: that is your starting point
npm run dev                                    # http://localhost:3006  (leave it running)
```

Open http://localhost:3006. It starts in **Demo** mode, a simulated blockchain, so you need no wallet and no Ganache.
You will see a yellow `TODO` box where the form should be. In the Demo mode the names `KA-2041-GH` and `GR-7710-AB`
are already registered, which is useful for testing a refusal.

Files you will touch: `utils/validation.ts` (step 1) and `components/RegistrationForm.tsx` (steps 2 to 6). **Do not**
change the other files. Commit after every step, with a message like `step 1: pseudonym validation rules`.

## 4. The steps

### Step 1. The rules (a pure function, tested first)

Open `utils/validation.ts` and `tests/validation.test.ts`. The tests are the specification. Make `npm test` go green.

`normalizePseudonym(raw)`: remove spaces at both ends, then make it upper case.

`validatePseudonym(raw)`: trim the value first, then check **in this order**; the first rule that fails decides the message:

| Order | Rule | Message (exact text) |
|---|---|---|
| 1 | empty | `Enter a pseudonym.` |
| 2 | fewer than 3 characters | `Use at least 3 characters.` |
| 3 | more than 32 characters | `Use at most 32 characters.` |
| 4 | anything except letters, digits, `-` | `Use letters, digits and hyphens only.` |
| 5 | starts or ends with `-` | `A pseudonym cannot start or end with a hyphen.` |
| | none of the above | return `null` |

`MIN_LENGTH` and `MAX_LENGTH` are already defined: use them, do not type 3 and 32 again in the messages' logic.

<details><summary>Hint 1: the character check</summary>

A regular expression can test "only these characters": `/^[A-Za-z0-9-]+$/.test(value)`. `^` and `$` mean "from the
start to the end", `+` means "one or more".
</details>
<details><summary>Hint 2: why does the order matter?</summary>

`"a!"` is both too short and has a bad character. The tests expect the first rule in the table. Early `return`s make
"first one wins" easy to write.
</details>

*What you learn:* logic with no React in it is easy to test and reuse. **Commit.**

### Step 2. A controlled input (state)

In `RegistrationForm.tsx` add state for the text, then render an `<input>` whose `value` comes from that state and
whose `onChange` updates it. Temporarily show `{value}` under the input to prove it works.

<details><summary>Hint</summary>

`const [value, setValue] = useState("");` and `onChange={(e) => setValue(e.target.value)}`. The input does not remember
anything itself: React does. That is what "controlled" means.
</details>

*What you learn:* ① state, ③ render, ② event handler: the three ideas from demo 2. **Commit.**

### Step 3. Validate, but only after the user has touched the field

Add `touched` state, set to `true` in the input's `onBlur`. Then **derive** three values (plain `const`s, not state):

- `error`: the result of `validatePseudonym(value)`
- `showError`: `touched && error !== null`
- Show `error` in a line under the input only when `showError` is true, and give the input the class `invalid` then.

<details><summary>Hint</summary>

Do not store `error` in state. If you did, you would have to remember to update it everywhere `value` changes, and
one day you would forget. A value that can be computed from other state should be computed.
</details>

*What you learn:* derived values; good UX (do not shout at someone who has not finished typing). **Commit.**

### Step 4. The button and the counter

Add `canSubmit` (no error and not pending). The Register button gets `disabled={!canSubmit}`. Show a counter
`{value.trim().length}/{MAX_LENGTH}` above the input, and add the class `over` to it when the length is above the maximum.

*What you learn:* the interface should make the wrong action impossible, not just report it. **Commit.**

### Step 5. Submit

Wrap the input and the button in a `<form onSubmit={handleSubmit} noValidate>` and make the button `type="submit"`. Now
Enter works too. Write `handleSubmit`:

1. `e.preventDefault()` (otherwise the browser reloads the page).
2. `setTouched(true)`; if `error !== null`, stop.
3. If there is no `api`, set the error state with the message `Connect the wallet first, or switch to demo mode.` and stop.
4. `setOp({ state: "pending", step: 0 })`, then `await api.register(normalizePseudonym(value), onProgress)`.
5. On success: `setOp({ state: "success", receipt })` and call `onRegistered(receipt)`.
6. On failure (`catch`): `setOp({ state: "error", message: friendlyError(err) })`.

In the render, show `<OperationSteps step=... detail=... />` while pending, a `msg err` box on error, and a `msg ok` box plus
`<ReceiptCard receipt=... />` on success. Disable the input while pending.

<details><summary>Hint: the progress callback</summary>

`api.register(name, (p, detail) => setOp({ state: "pending", step: p === "wallet" ? 0 : p === "submitted" ? 1 : 2, tx: detail }))`.
The callback is called three times as the transaction moves along; each call should move the steps forward.
</details>
<details><summary>Hint: the layout of the four states</summary>

`{op.state === "pending" && ...}` `{op.state === "error" && ...}` `{op.state === "success" && ...}`.
TypeScript knows that inside the first one `op.step` exists, and inside the last one `op.receipt` does.
</details>

*What you learn:* an asynchronous action with four screens, and why TypeScript's union types help. **Commit.**

### Step 6. Tidy up after the result

- After a **success**: empty the field (`setValue("")`), set `touched` back to `false`, and put the cursor back in the input.
- After a **failure**: keep what the user typed. They will want to fix it, not retype it.

For the cursor, add `const inputRef = useRef<HTMLInputElement>(null)`, attach it with `ref={inputRef}`, and focus it
in a `useEffect` that runs when `op.state` becomes `"success"`.

<details><summary>Hint: why not just call focus() in handleSubmit?</summary>

While the transaction is pending the input is disabled, and a disabled input cannot take focus. It is enabled again
only on the next render, after the state has changed. An effect runs after that render, so it works.
</details>

*What you learn:* side effects, and caring about the moment after the click. **Commit.**

## 5. Check your work

1. `npm test` is all green (8 tests).
2. `npm run typecheck` prints nothing.
3. In the browser (Demo mode), walk through AC1 to AC8 one by one. For AC8 use `KA-2041-GH` (a duplicate) and the
   checkbox *Simulate "reject in wallet"*.
4. Optional: ask your instructor how to switch to **Blockchain** mode (a local Ganache chain, or Sepolia with MetaMask) and register for real.

## 6. Review before you hand in

Read your own code as if a classmate wrote it.

- Does each name say what the thing is (`canSubmit`, not `flag`)?
- Is any rule written twice? (The rules live in `validation.ts` only.)
- Is anything stored in state that could be computed?
- Are there leftover `console.log`s or commented-out code?
- Does each commit message say what changed?
- Would a stranger understand your comments? Comments should say *why*, not repeat the code.

## 7. Stretch goals (choose one if you have time)

- **A "Suggest one" button** that fills in a name like `KA-4827-GH`. (Use the same rules: make sure it passes your own validation.)
- **Review before sending.** After the user presses Register, show "You are about to register KA-7001-XY. Confirm / Edit" and only send on Confirm.
- **Check for a duplicate while typing.** When the field is valid and the user leaves it, call `api.lookup(name)` and show "Already registered" at once. (Wait for the user to stop typing, and ignore an answer that arrives for a value that has changed.)
- **More tests.** Add boundary tests (exactly 3 and exactly 32 characters, a name made of 40 spaces, a pasted name with a tab).

## 8. Hand in

1. Your branch (`git log --oneline` should show about six commits).
2. A screenshot of the form in an **invalid** state, and one with a **receipt**.
3. A short reflection, three or four sentences each:
   - Which acceptance criterion was hardest, and why?
   - Why do we validate in the page when the contract also checks?
   - Which value did you derive instead of storing, and what would have gone wrong if you had stored it?
