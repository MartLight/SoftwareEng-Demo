import { useState } from "react";
import FilterBar, { Filter } from "./FilterBar";
import AddVehicleForm from "./AddVehicleForm";
import VehicleTable from "./VehicleTable";
import FlowLog, { LogLine } from "./FlowLog";
import { VEHICLES, Vehicle } from "../data/vehicles";

// The PARENT. The vehicles and the filter live here, in one place. Children
// never change them directly; they only report what the user did.
export default function RegistryScreen() {
  const [vehicles, setVehicles] = useState<Vehicle[]>(VEHICLES);
  const [filter, setFilter] = useState<Filter>("all");
  const [log, setLog] = useState<LogLine[]>([]);

  const say = (...lines: LogLine[]) => setLog((old) => [...lines.reverse(), ...old].slice(0, 40));

  function handleFilter(next: Filter) {
    setFilter(next);
    const shown = vehicles.filter((v) => next === "all" || v.status === next).length;
    say(
      { dir: "up", text: `FilterBar → onChange("${next}")` },
      { dir: "down", text: `RegistryScreen → VehicleTable receives ${shown} vehicle(s)` }
    );
  }

  function handleToggle(pseudonym: string) {
    setVehicles((old) =>
      old.map((v) =>
        v.pseudonym === pseudonym ? { ...v, status: v.status === "active" ? "revoked" : "active" } : v
      )
    );
    say(
      { dir: "up", text: `VehicleRow → onToggle("${pseudonym}")  (through VehicleTable)` },
      { dir: "down", text: `RegistryScreen → new vehicles array → VehicleTable → VehicleRow` }
    );
  }

  function handleAdd(pseudonym: string) {
    if (vehicles.some((v) => v.pseudonym === pseudonym)) {
      say({ dir: "up", text: `AddVehicleForm → onAdd("${pseudonym}")  ignored: already registered` });
      return;
    }
    const added: Vehicle = {
      pseudonym,
      owner: "0x0000...demo",
      registeredOn: new Date().toISOString().slice(0, 10),
      status: "active",
    };
    setVehicles((old) => [added, ...old]);
    say(
      { dir: "up", text: `AddVehicleForm → onAdd("${pseudonym}")` },
      { dir: "down", text: `RegistryScreen → VehicleTable receives ${vehicles.length + 1} vehicle(s)` }
    );
  }

  const visible = vehicles.filter((v) => filter === "all" || v.status === filter);

  return (
    <div className="grid2">
      <div className="card stack">
        <div className="row between">
          <h2 style={{ margin: 0 }}>Registry</h2>
          <FilterBar filter={filter} onChange={handleFilter} />
        </div>
        <AddVehicleForm onAdd={handleAdd} />
        <VehicleTable vehicles={visible} onToggle={handleToggle} />
      </div>
      <FlowLog lines={log} />
    </div>
  );
}
