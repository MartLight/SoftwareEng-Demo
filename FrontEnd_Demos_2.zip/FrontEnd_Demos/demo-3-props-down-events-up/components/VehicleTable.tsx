import VehicleRow from "./VehicleRow";
import { Vehicle } from "../data/vehicles";

interface VehicleTableProps {
  vehicles: Vehicle[];
  onToggle: (pseudonym: string) => void;
}

// A middle component: it passes data down and passes events up, and owns no data of its own.
export default function VehicleTable({ vehicles, onToggle }: VehicleTableProps) {
  if (vehicles.length === 0) return <div className="muted">No vehicles match this filter.</div>;
  return (
    <table className="tbl">
      <thead>
        <tr><th>Pseudonym</th><th>Status</th><th /></tr>
      </thead>
      <tbody>
        {vehicles.map((v) => (
          <VehicleRow key={v.pseudonym} vehicle={v} onToggle={onToggle} />
        ))}
      </tbody>
    </table>
  );
}
