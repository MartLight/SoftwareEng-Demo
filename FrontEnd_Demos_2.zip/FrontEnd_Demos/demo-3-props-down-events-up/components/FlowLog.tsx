export interface LogLine {
  dir: "up" | "down";
  text: string;
}

export default function FlowLog({ lines }: { lines: LogLine[] }) {
  return (
    <div className="card">
      <h2>Data flow log</h2>
      <div className="log">
        {lines.length === 0 && <div className="muted">Click a button on the left...</div>}
        {lines.map((l, i) => (
          <div key={i} className={l.dir}>
            {l.dir === "up" ? "↑ event  " : "↓ props  "}
            {l.text}
          </div>
        ))}
      </div>
      <p className="muted">
        <span style={{ color: "#b97a1f" }}>↑ amber</span>: a child reports an event to its parent.{" "}
        <span style={{ color: "#3a5578" }}>↓ blue</span>: the parent re-renders and passes new props down.
      </p>
    </div>
  );
}
