export type Filter = "all" | "active" | "revoked";

interface FilterBarProps {
  filter: Filter;                       // ↓ data comes down
  onChange: (next: Filter) => void;     // ↑ an event goes up
}

export default function FilterBar({ filter, onChange }: FilterBarProps) {
  const options: Filter[] = ["all", "active", "revoked"];
  return (
    <div className="tabs">
      {options.map((o) => (
        <button key={o} className={filter === o ? "on" : ""} onClick={() => onChange(o)}>
          {o}
        </button>
      ))}
    </div>
  );
}
