import { Vehicle } from "../data/vehicles";

interface VehicleRowProps {
  vehicle: Vehicle;                          // ↓ read-only data
  onToggle: (pseudonym: string) => void;     // ↑ event: "revoke / reinstate this one"
}

export default function VehicleRow({ vehicle, onToggle }: VehicleRowProps) {
  return (
    <tr>
      <td><b>{vehicle.pseudonym}</b></td>
      <td>
        <span className={`badge ${vehicle.status === "active" ? "ok" : "bad"}`}>{vehicle.status}</span>
      </td>
      <td style={{ textAlign: "right" }}>
        <button
          className={`btn small ${vehicle.status === "active" ? "danger" : "secondary"}`}
          onClick={() => onToggle(vehicle.pseudonym)}
        >
          {vehicle.status === "active" ? "Revoke" : "Reinstate"}
        </button>
      </td>
    </tr>
  );
}
