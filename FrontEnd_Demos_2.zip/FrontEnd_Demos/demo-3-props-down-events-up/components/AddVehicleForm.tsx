import { useState } from "react";

interface AddVehicleFormProps {
  onAdd: (pseudonym: string) => void;   // ↑ the form tells its parent; it does not store the vehicle itself
}

export default function AddVehicleForm({ onAdd }: AddVehicleFormProps) {
  const [text, setText] = useState(""); // state that belongs only to this form: the half-typed text

  function submit() {
    if (!text.trim()) return;
    onAdd(text.trim());
    setText("");
  }

  return (
    <div className="row">
      <input
        className="input"
        placeholder="New pseudonym, e.g. TN-6001-XY"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && submit()}
      />
      <button className="btn" onClick={submit}>Add</button>
    </div>
  );
}
