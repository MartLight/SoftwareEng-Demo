import RegistryScreen from "../components/RegistryScreen";

export default function Page() {
  return (
    <div className="container stack">
      <div className="hero">
        <h1>Demo 3: Props down, events up</h1>
        <div className="muted">
          Data flows down from the parent as props. Events flow up as function calls. The log shows both.
        </div>
      </div>
      <RegistryScreen />
    </div>
  );
}
