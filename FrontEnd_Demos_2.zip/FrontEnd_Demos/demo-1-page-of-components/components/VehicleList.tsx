import VehicleCard from "./VehicleCard";
import { Vehicle } from "../data/vehicles";

// Turns an array of data into an array of components.
export default function VehicleList({ vehicles }: { vehicles: Vehicle[] }) {
  return (
    <div className="comp card" data-name="VehicleList">
      <h2>Registered vehicles</h2>
      {vehicles.map((v) => (
        <VehicleCard key={v.pseudonym} vehicle={v} />
      ))}
    </div>
  );
}
