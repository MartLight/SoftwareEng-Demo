interface StatusBadgeProps {
  status: "active" | "revoked";
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  return (
    <span className={`comp badge ${status === "active" ? "ok" : "bad"}`} data-name="StatusBadge">
      {status}
    </span>
  );
}
