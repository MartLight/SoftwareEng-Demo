export default function Footer() {
  return (
    <div className="comp muted" data-name="Footer" style={{ textAlign: "center", paddingTop: 8 }}>
      Software Engineering · Demo 1 · a page is a composition of components
    </div>
  );
}
