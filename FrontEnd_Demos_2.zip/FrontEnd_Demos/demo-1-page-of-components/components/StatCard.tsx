// The smallest building block: one label and one number.
interface StatCardProps {
  label: string;
  value: number;
}

export default function StatCard({ label, value }: StatCardProps) {
  return (
    <div className="comp stat" data-name="StatCard">
      <b>{value}</b>
      <span className="muted">{label}</span>
    </div>
  );
}
