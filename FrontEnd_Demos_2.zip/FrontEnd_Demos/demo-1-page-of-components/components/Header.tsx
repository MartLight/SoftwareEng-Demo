// A component that only displays what it is given. It has no state and no logic.
interface HeaderProps {
  title: string;
  subtitle: string;
}

export default function Header({ title, subtitle }: HeaderProps) {
  return (
    <div className="comp hero" data-name="Header">
      <h1>{title}</h1>
      <div className="muted">{subtitle}</div>
    </div>
  );
}
