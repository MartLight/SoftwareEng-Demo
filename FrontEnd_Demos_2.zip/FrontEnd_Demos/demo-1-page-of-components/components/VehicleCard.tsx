import StatusBadge from "./StatusBadge";
import { Vehicle } from "../data/vehicles";

// One vehicle. The same component is reused once for every vehicle in the list.
export default function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  return (
    <div className="comp vcard" data-name="VehicleCard">
      <div className="row between">
        <span className="name">{vehicle.pseudonym}</span>
        <StatusBadge status={vehicle.status} />
      </div>
      <div className="muted">
        Owner {vehicle.owner} · registered {vehicle.registeredOn}
      </div>
    </div>
  );
}
