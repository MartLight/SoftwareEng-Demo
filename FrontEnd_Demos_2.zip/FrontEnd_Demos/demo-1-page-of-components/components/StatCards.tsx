import StatCard from "./StatCard";

interface StatCardsProps {
  total: number;
  active: number;
  revoked: number;
}

// A component made of smaller components: it composes three StatCards.
export default function StatCards({ total, active, revoked }: StatCardsProps) {
  return (
    <div className="comp stats" data-name="StatCards">
      <StatCard label="Registered vehicles" value={total} />
      <StatCard label="Active" value={active} />
      <StatCard label="Revoked" value={revoked} />
    </div>
  );
}
