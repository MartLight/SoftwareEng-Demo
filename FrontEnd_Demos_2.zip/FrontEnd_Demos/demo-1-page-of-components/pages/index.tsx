import { useState } from "react";
import Header from "../components/Header";
import StatCards from "../components/StatCards";
import VehicleList from "../components/VehicleList";
import Footer from "../components/Footer";
import { VEHICLES } from "../data/vehicles";

// The PAGE. It owns no layout details: it picks the components and gives each
// one the data it needs. Everything you see on screen comes from this list.
export default function HomePage() {
  const [xray, setXray] = useState(true);

  const active = VEHICLES.filter((v) => v.status === "active").length;

  return (
    <div className={xray ? "xray" : ""}>
      <div className="container stack">
        <div className="row between">
          <span className="muted">pages/index.tsx</span>
          <label className="row" style={{ cursor: "pointer" }}>
            <input type="checkbox" checked={xray} onChange={(e) => setXray(e.target.checked)} />
            Show component boundaries
          </label>
        </div>

        <Header title="Vehicle & License Registry" subtitle="Demo 1: one page, many components" />

        <div className="grid2">
          <div className="stack">
            <StatCards total={VEHICLES.length} active={active} revoked={VEHICLES.length - active} />
            <VehicleList vehicles={VEHICLES} />
          </div>

          <div className="card">
            <h2>The component tree</h2>
            <pre className="inspect">{`HomePage            (pages/index.tsx)
├─ Header
├─ StatCards
│  └─ StatCard × 3
├─ VehicleList
│  └─ VehicleCard × 4
│     └─ StatusBadge
└─ Footer`}</pre>
            <p className="muted">
              Tick and untick the box to see where each component starts and ends. Each outlined box is one
              file in <code>components/</code>. Notice that <code>VehicleCard</code> is written once and used
              four times.
            </p>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
}
