import { useState } from "react";
import OperationSteps, { Step } from "./OperationSteps";
import ReceiptCard from "./ReceiptCard";
import { RegistryApi } from "../utils/registry";
import { Receipt } from "../utils/receipts";
import { friendlyError } from "../utils/errors";

// The write path. Exactly one of four states is true at any time, and the screen follows it.
type Op =
  | { state: "idle" }
  | { state: "pending"; step: Step; tx?: string }
  | { state: "success"; receipt: Receipt }
  | { state: "error"; message: string };

interface RegisterFormProps {
  api: RegistryApi | null;
  onRegistered: (r: Receipt) => void;   // ↑ tell the parent so it can refresh what depends on it
}

export default function RegisterForm({ api, onRegistered }: RegisterFormProps) {
  const [pseudonym, setPseudonym] = useState("");
  const [op, setOp] = useState<Op>({ state: "idle" });

  async function submit() {
    const name = pseudonym.trim();
    if (!name) return setOp({ state: "error", message: "A pseudonym cannot be empty." });
    if (!api) return setOp({ state: "error", message: "Connect the wallet first, or switch to demo mode." });

    setOp({ state: "pending", step: 0 });
    try {
      const receipt = await api.register(name, (p, detail) =>
        setOp({ state: "pending", step: p === "wallet" ? 0 : p === "submitted" ? 1 : 2, tx: detail })
      );
      setOp({ state: "success", receipt });
      setPseudonym("");
      onRegistered(receipt);
    } catch (err) {
      setOp({ state: "error", message: friendlyError(err) });
    }
  }

  return (
    <div className="card stack">
      <h2>Register a vehicle (a write)</h2>
      <div className="row">
        <input
          className="input"
          placeholder="e.g. TN-6001-XY"
          value={pseudonym}
          disabled={op.state === "pending"}
          onChange={(e) => setPseudonym(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
        />
        <button className="btn" onClick={submit} disabled={op.state === "pending"}>
          {op.state === "pending" ? "Working..." : "Register"}
        </button>
      </div>

      {op.state === "pending" && <OperationSteps step={op.step} detail={op.tx} />}
      {op.state === "error" && <div className="msg err">{op.message}</div>}
      {op.state === "success" && (
        <>
          <div className="msg ok">Registered on the chain.</div>
          <ReceiptCard receipt={op.receipt} />
        </>
      )}
      <div className="muted">
        A write is different from a read: it asks the wallet to sign, costs gas, and takes a few seconds to be
        mined, so the screen must show progress and handle failure.
      </div>
    </div>
  );
}
