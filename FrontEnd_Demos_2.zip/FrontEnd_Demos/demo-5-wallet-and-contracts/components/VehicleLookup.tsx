import { useState } from "react";
import { Wallet, contractsFor } from "../utils/chain";

interface Info {
  isRegistered: boolean;
  owner: string;
  registeredAt: string;
  isRevoked: boolean;
}

export default function VehicleLookup({ wallet }: { wallet: Wallet | null }) {
  const [pseudonym, setPseudonym] = useState("");
  const [info, setInfo] = useState<Info | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function lookup() {
    if (!pseudonym.trim()) return;
    setLoading(true);
    setError("");
    setInfo(null);
    try {
      if (!wallet) throw new Error("Connect the wallet first.");
      const { registry, revocation } = contractsFor(wallet);
      const v: any = await registry.methods.getVehicle(pseudonym.trim()).call();
      const isRevoked: boolean = v.isRegistered ? await revocation.methods.isRevoked(pseudonym.trim()).call() : false;
      setInfo({
        isRegistered: v.isRegistered,
        owner: v.owner,
        registeredAt: v.isRegistered ? new Date(Number(v.registrationTime) * 1000).toLocaleString() : "",
        isRevoked,
      });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card stack">
      <h2>Look up a vehicle (a read)</h2>
      <div className="row">
        <input className="input" placeholder="pseudonym" value={pseudonym} onChange={(e) => setPseudonym(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && lookup()} />
        <button className="btn" onClick={lookup} disabled={loading}>{loading ? "Reading..." : "Look up"}</button>
      </div>
      {error && <div className="msg err">{error}</div>}
      {info && !info.isRegistered && <div className="msg warn">Nothing is registered under "{pseudonym}".</div>}
      {info && info.isRegistered && (
        <table className="tbl">
          <tbody>
            <tr><td>Owner</td><td><code>{info.owner}</code></td></tr>
            <tr><td>Registered</td><td>{info.registeredAt}</td></tr>
            <tr><td>Status</td><td><span className={`badge ${info.isRevoked ? "bad" : "ok"}`}>{info.isRevoked ? "revoked" : "active"}</span></td></tr>
          </tbody>
        </table>
      )}
      <div className="muted">
        A read calls <code>.call()</code>: it asks the chain a question, costs nothing, and asks the wallet for nothing.
      </div>
    </div>
  );
}
