import { ENV, isAddress } from "../utils/config";
import deployments from "../utils/deployments.json";

// Works with no wallet at all: it shows what the app was configured with.
export default function ConfigCard() {
  const rows: [string, string | undefined][] = [
    ["Chain id", ENV.chainId],
    ["VehicleRegistry", ENV.registry],
    ["RevocationManager", ENV.revocation],
    ["LicenseRegistry", ENV.license],
  ];
  const nets = Object.keys(deployments as object).filter((k) => !k.startsWith("_"));
  return (
    <div className="card">
      <h2>Configuration this app found</h2>
      <table className="tbl">
        <tbody>
          {rows.map(([label, value]) => (
            <tr key={label}>
              <td>{label}</td>
              <td>
                {value ? (
                  <code>{value.length > 20 ? value.slice(0, 10) + "..." + value.slice(-6) : value}</code>
                ) : (
                  <span className="muted">not set</span>
                )}
              </td>
              <td>
                {label !== "Chain id" && value && (
                  <span className={`badge ${isAddress(value) ? "ok" : "bad"}`}>
                    {isAddress(value) ? "valid" : "malformed"}
                  </span>
                )}
              </td>
            </tr>
          ))}
          <tr>
            <td>deployments.json</td>
            <td colSpan={2}>
              {nets.length ? <>chain ids: <code>{nets.join(", ")}</code></> : <span className="muted">empty (run npm run deploy:local or npm run sync)</span>}
            </td>
          </tr>
        </tbody>
      </table>
      <p className="muted">
        Source: the <code>NEXT_PUBLIC_…</code> lines of <code>.env.local</code> / <code>env.local</code>, and the
        addresses recorded in <code>utils/deployments.json</code>. No address is written in the code.
      </p>
    </div>
  );
}
