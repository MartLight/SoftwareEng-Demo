import { useState } from "react";
import { Wallet, contractsFor, resolveAddresses } from "../utils/chain";

interface Status {
  chainId: string;
  registry: string;
  revocation: string;
  license: string;
  licenseCount: string;
  admin: string;
  demo?: boolean;
}

const DEMO: Status = {
  chainId: "1337 (simulated)",
  registry: "0x5FbDB2315678afecb367f032d93F642f64180aa3",
  revocation: "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512",
  license: "0x9fE46736679d2D9a65F0992F2272dE9f3c7fa6e0",
  licenseCount: "3",
  admin: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
  demo: true,
};

// Reads from the chain. Every call here is free: no gas, no wallet pop-up.
export default function ContractStatus({ wallet }: { wallet: Wallet | null }) {
  const [status, setStatus] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function check() {
    setLoading(true);
    setError("");
    setStatus(null);
    try {
      if (!wallet) throw new Error("Connect the wallet first.");
      const { registry, revocation, license } = contractsFor(wallet);
      const licenseCount = await license.methods.licenseCount().call();
      const admin = await license.methods.admin().call();
      setStatus({
        chainId: wallet.chainId,
        registry: registry.options.address as string,
        revocation: revocation.options.address as string,
        license: license.options.address as string,
        licenseCount: String(licenseCount),
        admin: String(admin),
      });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  const source = wallet ? resolveAddresses(wallet.chainId).registry.source : null;

  return (
    <div className="card stack">
      <h2>System status (the walking skeleton)</h2>
      <div className="muted">Touches every layer: this component, the web3 library, a contract, the chain.</div>
      <div className="row">
        <button className="btn" onClick={check} disabled={loading}>{loading ? "Reading..." : "Read from the chain"}</button>
        {source && <span className="pill">addresses from: {source}</span>}
      </div>

      {error && (
        <div className="msg err">
          <b>The integration did not work.</b>
          <div>{error}</div>
          <div style={{ marginTop: 8 }}>
            <button className="btn small secondary" onClick={() => { setError(""); setStatus(DEMO); }}>
              Show demo data instead
            </button>
          </div>
        </div>
      )}

      {status && (
        <div>
          {status.demo && <div className="msg warn" style={{ marginBottom: 8 }}>DEMO DATA: simulated, not read from a chain.</div>}
          <table className="tbl">
            <tbody>
              <tr><td>Chain</td><td>{status.chainId}</td></tr>
              <tr><td>VehicleRegistry</td><td><code>{status.registry}</code></td></tr>
              <tr><td>RevocationManager</td><td><code>{status.revocation}</code></td></tr>
              <tr><td>LicenseRegistry</td><td><code>{status.license}</code></td></tr>
              <tr><td>Licenses issued</td><td>{status.licenseCount}</td></tr>
              <tr><td>Admin</td><td><code>{status.admin}</code></td></tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
