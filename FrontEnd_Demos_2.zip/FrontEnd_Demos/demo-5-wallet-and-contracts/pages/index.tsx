import { useCallback, useState } from "react";
import WalletBar from "../components/WalletBar";
import ConfigCard from "../components/ConfigCard";
import ContractStatus from "../components/ContractStatus";
import VehicleLookup from "../components/VehicleLookup";
import { Wallet } from "../utils/chain";

// The page owns the wallet and hands it down. Components that need the chain take it as a prop.
export default function Page() {
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const onDisconnected = useCallback(() => setWallet(null), []);

  return (
    <div className="container stack">
      <div className="hero">
        <h1>Demo 5: Connect the wallet and read from the chain</h1>
        <div className="muted">Steps 1 to 3 of the integration: wallet, addresses, contract objects, then reads.</div>
      </div>
      <WalletBar wallet={wallet} onConnected={setWallet} onDisconnected={onDisconnected} />
      <div className="grid2">
        <div className="stack">
          <ContractStatus wallet={wallet} />
          <VehicleLookup wallet={wallet} />
        </div>
        <ConfigCard />
      </div>
    </div>
  );
}
