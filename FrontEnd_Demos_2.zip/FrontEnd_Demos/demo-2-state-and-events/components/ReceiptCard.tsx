// ④ A CHILD component. It receives everything through props and cannot change them.
export interface Receipt {
  action: string;
  subject: string;
  txHash: string;
  blockNumber: number;
  time: string;
}

export default function ReceiptCard({ receipt }: { receipt: Receipt }) {
  return (
    <div className="receipt">
      <div className="head">
        <span>{receipt.action}</span>
        <span>{receipt.subject}</span>
      </div>
      <div className="line"><span>block</span><span>#{receipt.blockNumber}</span></div>
      <div className="line"><span>time</span><span>{receipt.time}</span></div>
      <div className="line"><span>tx</span><code>{receipt.txHash}</code></div>
    </div>
  );
}
