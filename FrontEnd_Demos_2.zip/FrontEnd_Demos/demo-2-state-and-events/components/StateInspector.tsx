// Shows the current values of the panel's state next to the panel, so students
// can watch the memory change as they type and click.
interface StateInspectorProps {
  values: Record<string, unknown>;
  renders: number;
}

export default function StateInspector({ values, renders }: StateInspectorProps) {
  return (
    <div className="card">
      <h2>Live state inspector</h2>
      <div className="row between" style={{ marginBottom: 8 }}>
        <span className="muted">Times this component has rendered</span>
        <span className="pill"><b>{renders}</b></span>
      </div>
      <pre className="inspect">{JSON.stringify(values, null, 2)}</pre>
      <p className="muted">
        Type in the box: <code>pseudonym</code> changes, so the component renders again. Press Register: three
        pieces of state change one after another and the screen follows each one.
      </p>
    </div>
  );
}
