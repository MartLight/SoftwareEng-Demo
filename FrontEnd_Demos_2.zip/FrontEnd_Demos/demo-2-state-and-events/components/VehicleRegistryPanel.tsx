import { useRef, useState } from "react";
import ReceiptCard, { Receipt } from "./ReceiptCard";
import StateInspector from "./StateInspector";

type Status = "idle" | "pending" | "success" | "error";

// A small stand-in for a blockchain call so the demo runs anywhere.
function fakeTransaction(pseudonym: string): Promise<Receipt> {
  return new Promise((resolve) =>
    setTimeout(
      () =>
        resolve({
          action: "Vehicle Registered",
          subject: pseudonym,
          txHash: "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
          blockNumber: Math.floor(Math.random() * 900) + 100,
          time: new Date().toLocaleTimeString(),
        }),
      900
    )
  );
}

export default function VehicleRegistryPanel() {
  // ① STATE: what this component remembers between renders.
  const [pseudonym, setPseudonym] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [receipt, setReceipt] = useState<Receipt | null>(null);

  // (Only for the demo: count how many times this function body runs.)
  const renders = useRef(0);
  renders.current += 1;

  // ② EVENT HANDLER: runs when the user acts. It changes state; it never edits the screen directly.
  async function handleRegister() {
    if (!pseudonym.trim()) {
      setStatus("error");
      return;
    }
    setStatus("pending");
    setReceipt(null);
    const result = await fakeTransaction(pseudonym.trim());
    setReceipt(result);
    setStatus("success");
    setPseudonym("");
  }

  // ③ RENDER: JSX describes the screen for the CURRENT state. Same state in, same screen out.
  return (
    <div className="grid2">
      <div className="card stack">
        <h2><span className="num">3</span>Register a vehicle</h2>

        <div>
          <label className="lbl"><span className="num">1</span>Pseudonym (state: <code>pseudonym</code>)</label>
          <div className="row">
            <input
              className="input"
              placeholder="e.g. KA-2041-GH"
              value={pseudonym}
              onChange={(e) => {
                setPseudonym(e.target.value);
                if (status === "error") setStatus("idle");
              }}
            />
            <button className="btn" onClick={handleRegister} disabled={status === "pending"}>
              <span style={{ opacity: 0.7, marginRight: 6 }}>②</span>
              {status === "pending" ? "Registering..." : "Register"}
            </button>
          </div>
        </div>

        {status === "error" && <div className="msg err">Type a pseudonym first.</div>}
        {status === "pending" && <div className="msg info">Sending the transaction (simulated, about one second)...</div>}
        {status === "success" && <div className="msg ok">Registered. The receipt below is a child component.</div>}

        {receipt && (
          <div>
            <div className="muted" style={{ marginBottom: 6 }}><span className="num">4</span>Child component, given props</div>
            <ReceiptCard receipt={receipt} />
          </div>
        )}
      </div>

      <StateInspector values={{ pseudonym, status, receipt }} renders={renders.current} />
    </div>
  );
}
