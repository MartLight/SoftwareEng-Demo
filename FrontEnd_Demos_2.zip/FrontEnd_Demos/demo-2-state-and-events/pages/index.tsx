import VehicleRegistryPanel from "../components/VehicleRegistryPanel";

export default function Page() {
  return (
    <div className="container stack">
      <div className="hero">
        <h1>Demo 2: Anatomy of a component</h1>
        <div className="muted">
          One component, four ideas: ① state, ② event handler, ③ render, ④ a child that receives props.
        </div>
      </div>
      <VehicleRegistryPanel />
    </div>
  );
}
