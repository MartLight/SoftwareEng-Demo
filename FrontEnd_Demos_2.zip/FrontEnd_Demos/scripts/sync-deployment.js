#!/usr/bin/env node
// Copies the main project's deployments and contract interfaces into the two blockchain demos.
//
//   npm run sync -- <path to the main project>            e.g.  npm run sync -- ../classtryout
//   npm run sync -- <path> --with-env                     also copies its NEXT_PUBLIC_ settings
//
// It reads   <project>/shared/deployments.json (or <project>/deployments.json)   and
//            <project>/shared/abi/{VehicleRegistry,RevocationManager,LicenseRegistry}.json
// and writes demo-5/utils and demo-6/utils (deployments.json, abi.json).
// It never reads or prints secrets: with --with-env only NEXT_PUBLIC_ lines are copied.
const fs = require("fs");
const path = require("path");

const args = process.argv.slice(2);
const project = args.find((a) => !a.startsWith("--"));
if (!project) {
  console.error("Usage: npm run sync -- <path to the main project> [--with-env]");
  process.exit(1);
}

const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const first = (...files) => files.find((f) => fs.existsSync(f));

const depFile = first(path.join(project, "shared", "deployments.json"), path.join(project, "deployments.json"));
if (!depFile) {
  console.error('No deployments.json found. Deploy first ("npm run deploy:local" in that project), then sync again.');
  process.exit(1);
}
const deployments = readJson(depFile);
const chainIds = Object.keys(deployments).filter((k) => !k.startsWith("_"));
if (!chainIds.length) {
  console.error("deployments.json lists no chain yet.");
  process.exit(1);
}

const names = ["VehicleRegistry", "RevocationManager", "LicenseRegistry"];
let abi = null;
const abiDir = path.join(project, "shared", "abi");
if (names.every((n) => fs.existsSync(path.join(abiDir, n + ".json")))) {
  abi = {};
  for (const n of names) {
    abi[n] = readJson(path.join(abiDir, n + ".json")).filter((x) => x.type === "function" || x.type === "event");
  }
}

const root = path.join(__dirname, "..");
for (const demo of ["demo-5-wallet-and-contracts", "demo-6-register-vehicle-module"]) {
  const dir = path.join(root, demo, "utils");
  fs.writeFileSync(path.join(dir, "deployments.json"), JSON.stringify(deployments, null, 2) + "\n");
  console.log("wrote", path.relative(root, path.join(dir, "deployments.json")));
  if (abi) {
    fs.writeFileSync(path.join(dir, "abi.json"), JSON.stringify(abi, null, 1) + "\n");
    console.log("wrote", path.relative(root, path.join(dir, "abi.json")));
  }
}
console.log("Chain ids found:", chainIds.join(", "));
if (!abi) console.log("No shared/abi folder found; the bundled interfaces were kept.");

if (args.includes("--with-env")) {
  const found = [".env.local", "env.local"].map((n) => path.join(project, n)).find((p) => fs.existsSync(p));
  if (!found) {
    console.log("No env file found in the project; skipped --with-env.");
  } else {
    const lines = fs.readFileSync(found, "utf8").split(/\r?\n/).filter((l) => l.trim().startsWith("NEXT_PUBLIC_"));
    fs.writeFileSync(path.join(root, ".env.local"), lines.join("\n") + "\n");
    console.log(`Copied ${lines.length} NEXT_PUBLIC_ setting(s) to .env.local in the pack root (values not shown).`);
  }
}
