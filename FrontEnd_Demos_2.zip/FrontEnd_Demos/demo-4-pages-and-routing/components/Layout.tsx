import { ReactNode } from "react";
import NavBar from "./NavBar";
import RouteInspector from "./RouteInspector";

// A layout wraps every page: the same navigation, the same frame, only the middle changes.
// `children` is whatever page is being shown.
export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div>
      <NavBar />
      <RouteInspector />
      <div className="container stack">{children}</div>
    </div>
  );
}
