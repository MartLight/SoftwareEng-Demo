import Link from "next/link";
import { useRouter } from "next/router";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/vehicles", label: "Vehicles" },
  { href: "/register", label: "Register" },
  { href: "/about", label: "About" },
];

// The navigation is a component, written once and shown on every page by Layout.
export default function NavBar() {
  const { pathname } = useRouter();
  return (
    <div className="nav">
      <div className="container">
        <span className="brand">Vehicle Registry</span>
        {LINKS.map((l) => {
          const active = l.href === "/" ? pathname === "/" : pathname.startsWith(l.href);
          return (
            <Link key={l.href} href={l.href} className={active ? "active" : ""}>
              {l.label}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
