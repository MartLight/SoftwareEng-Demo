import { useRouter } from "next/router";

// Shows what the router knows about the current page. Watch it change as you click.
export default function RouteInspector() {
  const router = useRouter();
  return (
    <div className="route">
      <div className="container">
        file: <b>pages{router.pathname === "/" ? "/index" : router.pathname}.tsx</b> &nbsp;|&nbsp; URL:{" "}
        <b>{router.asPath}</b> &nbsp;|&nbsp; query: <b>{JSON.stringify(router.query)}</b>
      </div>
    </div>
  );
}
