import { useState } from "react";
import { useRouter } from "next/router";
import { addVehicle, findVehicle } from "../data/vehicles";

export default function RegisterPage() {
  const router = useRouter();
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  function submit() {
    const pseudonym = text.trim();
    if (!pseudonym) return setError("Type a pseudonym first.");
    if (findVehicle(pseudonym)) return setError("That pseudonym is already registered.");
    addVehicle(pseudonym);
    // Navigate from code, not from a link: after registering, go to the new vehicle's page.
    router.push(`/vehicles/${encodeURIComponent(pseudonym)}`);
  }

  return (
    <div className="card stack">
      <h2>Register a vehicle</h2>
      <div className="row">
        <input className="input" placeholder="e.g. TN-6001-XY" value={text} onChange={(e) => setText(e.target.value)} />
        <button className="btn" onClick={submit}>Register</button>
      </div>
      {error && <div className="msg err">{error}</div>}
      <p className="muted">
        After a successful registration the code calls <code>router.push("/vehicles/…")</code>. Watch the strip
        above change to the dynamic route.
      </p>
    </div>
  );
}
