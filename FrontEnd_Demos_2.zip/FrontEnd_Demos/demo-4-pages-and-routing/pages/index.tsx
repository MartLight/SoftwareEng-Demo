import Link from "next/link";
import { VEHICLES } from "../data/vehicles";

export default function HomePage() {
  return (
    <>
      <div className="hero">
        <h1>Demo 4: Pages and routing</h1>
        <div className="muted">In Next.js every file in <code>pages/</code> is a URL. Click around and watch the strip above.</div>
      </div>

      <div className="card">
        <h2>The pages folder is the site map</h2>
        <table className="tbl">
          <thead><tr><th>File</th><th>URL</th><th>Try it</th></tr></thead>
          <tbody>
            <tr><td><code>pages/index.tsx</code></td><td>/</td><td>this page</td></tr>
            <tr><td><code>pages/vehicles/index.tsx</code></td><td>/vehicles</td><td><Link href="/vehicles">open</Link></td></tr>
            <tr>
              <td><code>pages/vehicles/[pseudonym].tsx</code></td>
              <td>/vehicles/<i>anything</i></td>
              <td><Link href={`/vehicles/${VEHICLES[0].pseudonym}`}>open {VEHICLES[0].pseudonym}</Link></td>
            </tr>
            <tr><td><code>pages/register.tsx</code></td><td>/register</td><td><Link href="/register">open</Link></td></tr>
            <tr><td><code>pages/about.tsx</code></td><td>/about</td><td><Link href="/about">open</Link></td></tr>
          </tbody>
        </table>
        <p className="muted">
          The square brackets in <code>[pseudonym].tsx</code> mean "any value here". The value arrives in{" "}
          <code>router.query.pseudonym</code>, and one file serves every vehicle.
        </p>
      </div>
    </>
  );
}
