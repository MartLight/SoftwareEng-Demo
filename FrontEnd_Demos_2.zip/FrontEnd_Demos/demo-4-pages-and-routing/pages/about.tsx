export default function AboutPage() {
  return (
    <div className="card">
      <h2>About this demo</h2>
      <p>
        Every page shares the same <code>Layout</code>, <code>NavBar</code> and <code>RouteInspector</code>. They are
        written once in <code>_app.tsx</code> and <code>components/</code>. Moving between pages does not reload the
        browser: Next.js swaps only the middle.
      </p>
      <p className="muted">
        Try this: register a vehicle, then open <code>/vehicles</code>. The new vehicle is there, because every page
        imports the same data module. A real app would read it from the chain instead.
      </p>
    </div>
  );
}
