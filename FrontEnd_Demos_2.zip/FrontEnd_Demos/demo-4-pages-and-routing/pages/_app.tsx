import type { AppProps } from "next/app";
import Layout from "../components/Layout";
import "../styles/demo.css";

// _app.tsx wraps every page, so the Layout is added once here, not in each page.
export default function App({ Component, pageProps }: AppProps) {
  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}
