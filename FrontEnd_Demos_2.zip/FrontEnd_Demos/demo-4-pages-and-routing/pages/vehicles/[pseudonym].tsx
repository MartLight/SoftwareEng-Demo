import Link from "next/link";
import { useRouter } from "next/router";
import { findVehicle } from "../../data/vehicles";

// One file, many URLs. The part of the URL in the brackets is read from the router.
export default function VehicleDetailPage() {
  const router = useRouter();
  const pseudonym = router.query.pseudonym as string | undefined;
  const vehicle = pseudonym ? findVehicle(pseudonym) : undefined;

  if (!router.isReady) return <div className="muted">Loading...</div>;

  if (!vehicle) {
    return (
      <div className="card">
        <h2>No such vehicle</h2>
        <div className="msg warn">Nothing is registered under "{pseudonym}".</div>
        <p><Link href="/vehicles">Back to the list</Link></p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>{vehicle.pseudonym}</h2>
      <p>
        <span className={`badge ${vehicle.status === "active" ? "ok" : "bad"}`}>{vehicle.status}</span>
      </p>
      <p className="muted">Owner {vehicle.owner} · registered {vehicle.registeredOn}</p>
      <p><Link href="/vehicles">← Back to the list</Link></p>
    </div>
  );
}
