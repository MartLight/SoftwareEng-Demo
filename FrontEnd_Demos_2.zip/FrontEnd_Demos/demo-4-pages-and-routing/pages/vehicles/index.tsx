import Link from "next/link";
import { VEHICLES } from "../../data/vehicles";

export default function VehiclesPage() {
  return (
    <div className="card">
      <h2>Vehicles</h2>
      <table className="tbl">
        <thead><tr><th>Pseudonym</th><th>Status</th><th>Registered</th></tr></thead>
        <tbody>
          {VEHICLES.map((v) => (
            <tr key={v.pseudonym}>
              <td><Link href={`/vehicles/${v.pseudonym}`}>{v.pseudonym}</Link></td>
              <td><span className={`badge ${v.status === "active" ? "ok" : "bad"}`}>{v.status}</span></td>
              <td>{v.registeredOn}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="muted">Each name is a link to the dynamic page <code>/vehicles/[pseudonym]</code>.</p>
    </div>
  );
}
