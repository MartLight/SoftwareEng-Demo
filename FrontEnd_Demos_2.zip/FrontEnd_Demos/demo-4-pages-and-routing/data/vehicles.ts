// Sample data standing in for what the blockchain would return.
export interface Vehicle {
  pseudonym: string;
  owner: string;
  registeredOn: string;
  status: "active" | "revoked";
}

export const VEHICLES: Vehicle[] = [
  { pseudonym: "KA-2041-GH", owner: "0x71C7...9a3F", registeredOn: "2026-03-02", status: "active" },
  { pseudonym: "GR-7710-AB", owner: "0x5B38...dC4a", registeredOn: "2026-03-09", status: "active" },
  { pseudonym: "WR-3392-CD", owner: "0xAb84...5E21", registeredOn: "2026-04-17", status: "revoked" },
  { pseudonym: "AS-5518-EF", owner: "0x4E83...b7D0", registeredOn: "2026-05-21", status: "active" },
];

// A tiny in-memory "database". It lives as long as the browser tab stays open.
// Pages share it because they all import the same module.
export function findVehicle(pseudonym: string): Vehicle | undefined {
  return VEHICLES.find((v) => v.pseudonym === pseudonym);
}

export function addVehicle(pseudonym: string): Vehicle {
  const v: Vehicle = {
    pseudonym,
    owner: "0x0000...demo",
    registeredOn: new Date().toISOString().slice(0, 10),
    status: "active",
  };
  VEHICLES.unshift(v);
  return v;
}
