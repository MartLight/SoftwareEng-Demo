# Front-End Demos: pages, components and smart-contract integration

Six small apps for the front-end module in Week 9. Each one runs on its own and **shows something the moment it
starts**. Together they follow the slides: components, state and events, props and events, pages and routing, then
the smart-contract integration.

Same stack as the class app: Next.js 14 (pages router), React 18, TypeScript, web3.js v4. Nothing here touches
`ClassTryout` or the class repository. This folder is self-contained.

## Run it (once per computer)

```bash
npm install          # one install at this folder serves all six demos (npm workspaces)
npm run demo1        # opens on http://localhost:3001
```

Every demo is also a **complete project of its own**, with its own `package.json`, `tsconfig.json` and
`next.config.js`. To run just one: `cd demo-1-page-of-components`, `npm install`, `npm run dev`.

The settings come from the main project (ClassTryout): the same `tsconfig.json` (bundler module resolution, the
`@/*` path alias, `allowJs`), the same dependency versions (Next 14.2.15, React 18.3.1, web3 ^4.16), and, for
demos 5 and 6, its Truffle config, contracts, migrations, contract interfaces and chain list.

| Command | Port | Concept (slide) | Needs a chain? |
|---|---|---|---|
| `npm run demo1` | 3001 | A page composes components | no |
| `npm run demo2` | 3002 | Anatomy of a component: state, handler, render, child | no |
| `npm run demo3` | 3003 | Props down, events up | no |
| `npm run demo4` | 3004 | Pages and routing in Next.js | no |
| `npm run demo5` | 3005 | Connect the wallet, load the contracts, read from the chain | optional |
| `npm run demo6` | 3006 | A complete module: register (write), look up (read), progress, success, failure | optional |

Run several at once by opening several terminals. Stop one with Ctrl+C. `npm run check` type-checks all six.

Note: Next.js 14.2.15 is the version pinned in the main project. npm prints a security notice for it; upgrading is a
decision for the main project, and the demos follow it so the two stay alike.

Demos 1 to 4 need nothing but Node 18 or newer. Demos 5 and 6 work **without** a blockchain too: demo 5 offers
"Show demo data instead" when the integration fails, and demo 6 starts in **Demo** mode with a simulated chain.
Switch to **Blockchain** to use the real contracts.

---

## How the demos connect to the slides

The demos belong to **Week 9 (Construction and Code Quality)** of the student deck, in the block of eleven slides
that follows "Practical: Logging a Confirmed Transaction" (slide numbers are for the 140-slide student deck and
will shift if slides are added). Use a demo right after the slide it supports: slide first for the idea, demo second
for proof, then the exercise.

| Demo | Slides it supports | What it teaches | Where to look in the code |
|---|---|---|---|
| **1** Page of components | 97 *A Front-End Module: Pages, Components and Logic*, 98 *A Page Composes Components* | A screen is a tree of small components. A page chooses the components and hands each its data. One component (`VehicleCard`) is written once and reused. | `pages/index.tsx` (the page), `components/` (one file per building block) |
| **2** State and events | 99 *Anatomy of a Component* | The four parts of a component: ① state, ② event handler, ③ render, ④ a child that receives props. State changes cause a new render. Handlers change state; they never edit the screen. | `components/VehicleRegistryPanel.tsx` (the numbered comments match the slide), `StateInspector.tsx` |
| **3** Props down, events up | 100 *Props Down, Events Up: How Data Moves* | Data flows down as props and is read-only for the child. Events flow up as function calls. State lives in the lowest parent that needs it. | `components/RegistryScreen.tsx` (the parent), `VehicleRow.tsx` (the child), `FlowLog.tsx` |
| **4** Pages and routing | 101 *Pages and Routing in Next.js* | Each file in `pages/` is a URL. `[pseudonym].tsx` is a dynamic route read from `router.query`. `router.push` navigates from code. A layout is added once in `_app.tsx`. | `pages/`, `pages/vehicles/[pseudonym].tsx`, `components/Layout.tsx`, `NavBar.tsx` |
| **5** Wallet and contracts | 103 *Integrating a Smart Contract With the Front End*, 104 *Step 1: Connect the Wallet and Load the Contracts*, first half of 105 (*Read*) | Integration is a short pipeline: connect the wallet, find the right addresses for the chain, build contract objects, then read with `.call()`. No contract address is written in the source. A failed integration must show a useful message and a fallback. | `utils/chain.ts` (Steps 1 to 3 are commented), `components/WalletBar.tsx`, `ContractStatus.tsx`, `ConfigCard.tsx` |
| **6** Register-vehicle module | 102 *Building One Front-End Module, Step by Step*, second half of 105 (*Write*), 106 *Step 4: Show Progress, Success and Failure*, 107 *When the Integration Does Not Work* | Everything together as one module. A write is not a read: it needs a signature, costs gas and takes seconds, so the screen has four states (idle, pending, success, error) and shows progress. Errors are translated for the user. The screen talks to a small interface with two implementations (simulated and real chain), which is also how the module is tested without a blockchain. | `components/VehicleModule.tsx` (the module), `RegisterForm.tsx` (the four states), `OperationSteps.tsx`, `utils/registry.ts` (the interface), `utils/errors.ts` |

### The ideas, in the order the slides teach them

1. **Compose** (demo 1): build screens from small pieces; reuse beats copying.
2. **Remember and react** (demo 2): state is the component's memory; the screen is a function of state.
3. **Share** (demo 3): when two components need the same data, move it up to their parent and pass it down.
4. **Navigate** (demo 4): a site is a set of pages; the file name decides the URL.
5. **Connect** (demo 5): reading from a contract is the same pattern as any asynchronous call, plus wallet and chain checks.
6. **Write and recover** (demo 6): treat success, waiting and failure as first-class screens, not afterthoughts.

### Links to the rest of the course

- **Software design (Weeks 7 and 8):** demo 6's `RegistryApi` interface is the repository-interface idea from the
  Week 8 architecture slides: the screen depends on an abstraction, so the data source can be swapped.
- **Testing (Week 10):** the simulated implementation in demo 6 is a test double, the same technique the unit tests
  use for the services.
- **Code quality (Week 9, the same week):** the demos show small files, one job per component, names that say what a
  thing is, and comments that explain why. Ask students to review a demo against the Week 9 code-quality checklist.
- **The course project:** students build their own feature as a module in the same shape: a page, a few components,
  one place that talks to the chain, and the four states.

### Suggested session plan (one 2-hour lab)

| Time | Activity |
|---|---|
| 0:00 | Slides 97 to 98, then demo 1 (compose) |
| 0:20 | Slide 99, then demo 2 (state and events) |
| 0:40 | Slide 100, then demo 3 (props and events) |
| 1:00 | Slide 101, then demo 4 (routing) |
| 1:20 | Slides 103 to 105, then demo 5 (connect and read) |
| 1:45 | Slides 106 to 107, then demo 6 (write, progress, failure) |

For a split across two lectures, do demos 1 to 4 in the first and 5 to 6 in the second.

---

## What to do in class

### Demo 1: a page composes components (about 10 minutes)
Open it and leave "Show component boundaries" ticked. Every dashed box is one file in `components/`.
Point at `VehicleCard`: written once, drawn four times. Then open `pages/index.tsx` and show that the page only
chooses components and gives them data. **Try:** add a fifth vehicle to `data/vehicles.ts` and watch every count and
the list change without touching a component.

### Demo 2: anatomy of a component (about 15 minutes)
The numbered markers match the slide: ① state, ② event handler, ③ render, ④ child with props. The inspector on the
right shows the state live. **Try:** type in the box (state changes, the render counter goes up), press Register
(three state changes in a row), and press Register with an empty box (the error state). **Ask:** why does the
handler call `setStatus` instead of changing the screen?

### Demo 3: props down, events up (about 15 minutes)
Revoke a vehicle, switch the filter, add one. The log on the right prints every event going up (amber) and every
re-render going down (blue). Notice that `VehicleRow` never changes the list: it only calls `onToggle`, and the
parent owns the list. **Try:** move the `vehicles` state into `VehicleRow` and see why it cannot work.

### Demo 4: pages and routing (about 15 minutes)
The strip under the menu shows the file, the URL and the query for the current page. Click through the pages,
open a vehicle (one file, `[pseudonym].tsx`, serves every URL), then register one: the code calls `router.push`
and lands on the new dynamic page. `Layout` is added once in `_app.tsx`. **Try:** add `pages/contact.tsx` and a
link to it.

### Demo 5: wallet and reads (about 20 minutes)
Without a wallet: press "Read from the chain" and read the error aloud, then press "Show demo data instead". That
is the failure path every integration needs. With Ganache and MetaMask: connect, read, look up a vehicle.
The right-hand card shows which configuration the app found. **Ask:** why is no contract address in the source code?

### Demo 6: the whole module (about 25 minutes)
Start in **Demo** mode: register a vehicle and watch the four steps (confirm, sent, in a block, receipt). Register
the same name again (a contract rule fails), then tick "Simulate reject in wallet" and register (the user says no).
Then switch to **Blockchain** and repeat on the real contracts. The screen code is identical because it talks to a
small interface (`utils/registry.ts`) with two implementations. That is the design point to teach.

---

## Using the real contracts (demos 5 and 6)

**Quickest: Sepolia, no setup.** The pack already contains the main project's `deployments.json`, which lists its
Sepolia deployment. Put MetaMask on Sepolia, start demo 5 or 6 and press Connect Wallet. Reads are free; a
registration needs a little Sepolia test ETH.

**Local Ganache.** Demos 5 and 6 each carry the main project's Truffle setup (`truffle-config.js`, `contracts/`,
`migrations/`, `shared/chains.json`) and the same script names. From inside `demo-6-register-vehicle-module` (or demo 5):

```bash
npm run chain            # Ganache on port 7545, chain id 1337 (leave it running)
npm run deploy:local     # deploys the three contracts; addresses are recorded in utils/deployments.json
```

In MetaMask add the network (RPC `http://127.0.0.1:7545`, chain id 1337) and import one Ganache account, then
restart the demo. To use the same deployment in the other demo, run `npm run sync` (below) or copy
`utils/deployments.json`. `npm run deploy:sepolia` works the same way; it needs `TESTNET_PRIVATE_KEY` or
`TESTNET_MNEMONIC` in `.env.local` (a throwaway wallet only).

**Or reuse the main project's own deployment.** From this folder:

```bash
npm run sync -- ../path/to/classtryout            # copies its deployments.json and contract interfaces
npm run sync -- ../path/to/classtryout --with-env # also copies its NEXT_PUBLIC_ settings (never secrets)
```

**Environment file.** Copy the project's `env.local` (or `.env.local`) into this folder or into a demo folder. Only
lines starting with `NEXT_PUBLIC_` reach the browser; `MNEMONIC`, private keys and other secrets are ignored on
purpose (Truffle reads the `TESTNET_` ones itself, on your computer only). Optional overrides:
`NEXT_PUBLIC_DEPLOYED_CHAIN_ID`, `NEXT_PUBLIC_VEHICLE_REGISTRY_ADDRESS`, `NEXT_PUBLIC_REVOCATION_MANAGER_ADDRESS`,
`NEXT_PUBLIC_LICENSE_REGISTRY_ADDRESS`. Addresses in the environment file win over `deployments.json` and apply only
to the chain id they were set for. Restart after changing the file.

`utils/deployments.json` has the main project's shape (`{ "<chainId>": { "VehicleRegistry": { "address": … } } }`),
so the two files are interchangeable. `utils/abi.json` holds the interfaces generated by the main project.

## Folder map

```
scripts/sync-deployment.js     copies deployments and interfaces from the main project
demo-N-.../
  package.json  tsconfig.json  next.config.js  loadEnv.js     the project's own settings
  pages/        one file per URL (index.tsx, plus _app.tsx)
  components/   the building blocks
  data/         sample data (demos 1 to 4)
  utils/        chain, config, registry, errors, abi, deployments (demos 5 and 6)
  truffle-config.js  contracts/  migrations/  scripts/  shared/chains.json    (demos 5 and 6)
  styles/demo.css
```

## Taking a demo into the class repository

Copy a demo's `components/` and `utils/` into the class repository's `components/` and `utils/` folders, and the
`styles/demo.css` rules you need. Demo 6's `VehicleModule` can replace the Week 4 registration panel once students
understand it.

## Troubleshooting

- **Port already in use:** stop the other process, or run `npx next dev demo-1-page-of-components -p 3101`.
- **"Connect the wallet first" in demo 5 or 6:** press Connect Wallet. In demo 6, Demo mode needs no wallet.
- **"... is not deployed on chain N":** the chain MetaMask is on has no entry in `utils/deployments.json`. Run
  `npm run deploy:local` (Ganache running), or `npm run sync`, or switch MetaMask to Sepolia.
- **MetaMask shows the wrong network:** switch it to the Ganache network. The page reloads when the network changes.
- **Changed `env.local` but nothing happened:** restart the demo; the file is read at start-up.

## What was tested

All six demos type-check, start with `npm run demoN` (and demo 1 also on its own after copying the folder out and
running `npm install`), and were driven in a real browser: every page of demo 4, the failure and success paths of
demos 5 and 6 in Demo mode, and, against the main project's own contracts (the Ownable and Pausable versions)
deployed to a local Ganache chain with the demo's Truffle config and migrations, a real registration, a duplicate
rejection and a lookup. The browser wallet was a small stand-in that forwards to Ganache. **Not tested:** the
MetaMask extension itself, a live Sepolia read or write, `truffle compile` with the online compiler download (the
contracts were compiled with the same solc 0.8.20 locally), and Windows paths for `sync`.
